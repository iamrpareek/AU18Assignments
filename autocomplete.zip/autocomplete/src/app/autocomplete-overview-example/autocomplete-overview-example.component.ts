// import {Component, OnInit} from '@angular/core';
// import {FormBuilder, FormGroup} from '@angular/forms';
// import {Observable} from 'rxjs';
// import {startWith, map} from 'rxjs/operators';

// export interface StateGroup {
//   letter: string;
//   names: string[];
// }

// export const _filter = (opt: string[], value: string): string[] => {
//   const filterValue = value.toLowerCase();

//   return opt.filter(item => item.toLowerCase().indexOf(filterValue) === 0);
// };

// /**
//  * @title Option groups autocomplete
//  */
// @Component({
//   templateUrl: './autocomplete-optgroup-example.html',
//   styleUrls: ['./autocomplete-optgroup-example.css'],
// })

// export class AutocompleteOptgroupExample implements OnInit {
//   stateForm: FormGroup = this.fb.group({
//     stateGroup: '',
//   });

//   stateGroups: StateGroup[] = [{
//     letter: 'A',
//     names: ['Alabama', 'Alaska', 'Arizona', 'Arkansas']
//   }, {
//     letter: 'C',
//     names: ['California', 'Colorado', 'Connecticut']
//   }, {
//     letter: 'D',
//     names: ['Delaware']
//   }, {
//     letter: 'F',
//     names: ['Florida']
//   }, {
//     letter: 'G',
//     names: ['Georgia']
//   }, {
//     letter: 'H',
//     names: ['Hawaii']
//   }, {
//     letter: 'I',
//     names: ['Idaho', 'Illinois', 'Indiana', 'Iowa']
//   }, {
//     letter: 'K',
//     names: ['Kansas', 'Kentucky']
//   }, {
//     letter: 'L',
//     names: ['Louisiana']
//   }, {
//     letter: 'M',
//     names: ['Maine', 'Maryland', 'Massachusetts', 'Michigan',
//       'Minnesota', 'Mississippi', 'Missouri', 'Montana']
//   }, {
//     letter: 'N',
//     names: ['Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
//       'New Mexico', 'New York', 'North Carolina', 'North Dakota']
//   }, {
//     letter: 'O',
//     names: ['Ohio', 'Oklahoma', 'Oregon']
//   }, {
//     letter: 'P',
//     names: ['Pennsylvania']
//   }, {
//     letter: 'R',
//     names: ['Rhode Island']
//   }, {
//     letter: 'S',
//     names: ['South Carolina', 'South Dakota']
//   }, {
//     letter: 'T',
//     names: ['Tennessee', 'Texas']
//   }, {
//     letter: 'U',
//     names: ['Utah']
//   }, {
//     letter: 'V',
//     names: ['Vermont', 'Virginia']
//   }, {
//     letter: 'W',
//     names: ['Washington', 'West Virginia', 'Wisconsin', 'Wyoming']
//   }];

//   stateGroupOptions: Observable<StateGroup[]>;

//   constructor(private fb: FormBuilder) {}

//   ngOnInit() {
//     this.stateGroupOptions = this.stateForm.get('stateGroup')!.valueChanges
//       .pipe(
//         startWith(''),
//         map(value => this._filterGroup(value))
//       );
//   }

//   private _filterGroup(value: string): StateGroup[] {
//     if (value) {
//       return this.stateGroups
//         .map(group => ({letter: group.letter, names: _filter(group.names, value)}))
//         .filter(group => group.names.length > 0);
//     }

//     return this.stateGroups;
//   }
// }

import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatChipInputEvent } from '@angular/material';
import { Observable } from 'rxjs';
import { map} from 'rxjs/operators/map';
import { startWith } from 'rxjs/operators/startWith';
import 'rxjs/add/operator/catch';

export interface StateGroup {
  letter: string;
  names: string[];
}

@Component({
  selector: 'autocomplete-overview-example',
  templateUrl: './autocomplete-overview-example.component.html',
  styleUrls: ['./autocomplete-overview-example.component.css'],
  providers: []
})


export class AutocompleteOverviewExample implements OnInit {

  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  stateCtrl = new FormControl();
  filteredstates: Observable<string[]>;
  states: string[] = [];
  allstates: string[] = ["Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Anguilla", "Antigua &amp; Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia &amp; Herzegovina", "Botswana", "Brazil", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Cape Verde", "Cayman Islands", "Chad", "Chile", "China", "Colombia", "Congo", "Cook Islands", "Costa Rica", "Cote D Ivoire", "Croatia", "Cruise Ship", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Polynesia", "French West Indies", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea Bissau", "Guyana", "Haiti", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kuwait", "Kyrgyz Republic", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Mauritania", "Mauritius", "Mexico", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Namibia", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Norway", "Oman", "Pakistan", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russia", "Rwanda", "Saint Pierre &amp; Miquelon", "Samoa", "San Marino", "Satellite", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "South Africa", "South Korea", "Spain", "Sri Lanka", "St Kitts &amp; Nevis", "St Lucia", "St Vincent", "St. Lucia", "Sudan", "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor L'Este", "Togo", "Tonga", "Trinidad &amp; Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks &amp; Caicos", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Venezuela", "Vietnam", "Virgin Islands (US)", "Yemen", "Zambia", "Zimbabwe"];

  stateGroups: StateGroup[] = [
    {
      letter: 'A',
      names: ['Alabama', 'Alaska', 'Arizona', 'Arkansas']
    }, {
      letter: 'C',
      names: ['California', 'Colorado', 'Connecticut']
    }, {
      letter: 'D',
      names: ['Delaware']
    }, {
      letter: 'F',
      names: ['Florida']
    }, {
      letter: 'G',
      names: ['Georgia']
    }, {
      letter: 'H',
      names: ['Hawaii']
    }, {
      letter: 'I',
      names: ['Idaho', 'Illinois', 'Indiana', 'Iowa']
    }, {
      letter: 'K',
      names: ['Kansas', 'Kentucky']
    }, {
      letter: 'L',
      names: ['Louisiana']
    }, {
      letter: 'M',
      names: ['Maine', 'Maryland', 'Massachusetts', 'Michigan',
        'Minnesota', 'Mississippi', 'Missouri', 'Montana']
    }, {
      letter: 'N',
      names: ['Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
        'New Mexico', 'New York', 'North Carolina', 'North Dakota']
    }, {
      letter: 'O',
      names: ['Ohio', 'Oklahoma', 'Oregon']
    }, {
      letter: 'P',
      names: ['Pennsylvania']
    }, {
      letter: 'R',
      names: ['Rhode Island']
    }, {
      letter: 'S',
      names: ['South Carolina', 'South Dakota']
    }, {
      letter: 'T',
      names: ['Tennessee', 'Texas']
    }, {
      letter: 'U',
      names: ['Utah']
    }, {
      letter: 'V',
      names: ['Vermont', 'Virginia']
    }, {
      letter: 'W',
      names: ['Washington', 'West Virginia', 'Wisconsin', 'Wyoming']
    }];

  StateForm: FormGroup;
  stateGroupOptions: Observable<StateGroup[]>;

  @ViewChild('stateInput') stateInput: ElementRef<HTMLInputElement>;

  constructor(private fb: FormBuilder) {
    this.formBuild();
    
    this.filteredstates = this.StateForm.get('stateGroups').valueChanges.pipe(
      startWith(null),
      map((state: string | null) => state ? this._filter(state) : this.allstates.slice()));
      console.log("Reeee");
      
      this.stateGroupOptions = this.StateForm.get('stateGroups').valueChanges.pipe(
        startWith(null),
        map ((val: string) => { console.log("2"); console.log(val); return this.filterGroup(val) }));
  
  }

  ngOnInit() {
    console.log("1");

  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our state
    if ((value || '').trim()) {
      this.states.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.stateCtrl.setValue(null);
  }

  formBuild() {
    {
      this.StateForm = this.fb.group({
        stateGroups: ['', [Validators.required]]
      })
    };
  }

  remove(state: string): void {
    const index = this.states.indexOf(state);

    if (index >= 0) {
      this.states.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.states.push(event.option.viewValue);
    this.stateInput.nativeElement.value = '';
    this.stateCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allstates.filter(state => state.toLowerCase().indexOf(filterValue) === 0);
  }

  filterGroup(val: string): StateGroup[] {
    console.log("Yo");
    if (val) {
      return this.stateGroups
        .map(group => ({ letter: group.letter, names: this._filter1(group.names, val) }))
        .filter(group => group.names.length > 0);
    }
    console.log(this.stateGroups);
    return this.stateGroups;
  }

  private _filter1(opt: string[], val: string) {
    const filterValue = val.toLowerCase();
    return opt.filter(item => item.toLowerCase().startsWith(filterValue));
  }

}