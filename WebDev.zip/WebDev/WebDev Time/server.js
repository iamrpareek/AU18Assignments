var express = require('express'),
app = express(),
server = require('http').createServer(app),
io = require('socket.io').listen(server),
nicknames = [];
 
server.listen(3001);

app.get('/', function(req, res){
res.sendFile(__dirname + '/chat.html');
});
 
io.sockets.on('connection', function(socket){

socket.on('editTime',function(data){
	var newDate= new Date(data);
	io.sockets.emit('updateAll',newDate);
});

socket.on('resetTime',function(){
	var newDate= new Date();
	io.sockets.emit('resetAll',newDate);
});

});