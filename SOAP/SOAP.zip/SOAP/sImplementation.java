import java.util.*;
import javax.jws.WebService;

@WebService(endpointInterface = "sAssignment.sInterface")
public class sImplementation implements sInterface{	
	
	ArrayList<String> s = new ArrayList<String>(Arrays.asList("Rahul", "David", "Cristi"));
	
	@Override
	public String add(String n) {
		s.add(n);
		return n+" added!";
	}
	
	@Override
	public String delete(String n) {
		int k = s.indexOf(n);
		s.remove(k);
		return n+" deleted!";
	}
	
	@Override
	public String update(String n1, String n2) {
		int k = s.indexOf(n1);
		s.set(k, n2);
		return "Updated!";
	}
	
	@Override
	public String get(int k) {
		return s.get(k);	
	}
}
