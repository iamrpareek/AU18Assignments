import javax.xml.ws.Endpoint;

public class sPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8080/WS/sAssignment", new sImplementation());
		
	}
}