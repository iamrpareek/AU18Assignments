import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface sInterface {
	
	@WebMethod
	String add(String n);
	
	@WebMethod
	String delete(String n);
	
	@WebMethod
	String update(String n1, String n2);
	
	@WebMethod
	public String get(int n);
}
