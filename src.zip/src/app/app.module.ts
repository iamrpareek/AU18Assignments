import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule  } from '@angular/forms';

import { AppComponent } from './app.component';
import { ListBookComponent } from './list-book/list-book.component';
import { ListAuthorComponent } from './list-author/list-author.component';
import { Page404Component } from './page404/page404.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { NameComponent } from './name/name.component';

const appRoutes: Routes = [
  { path: 'booksPage', component: ListBookComponent },
  { path: 'authorsPage', component: ListAuthorComponent },
  { path: 'enterNamePage', component: NameComponent },
  { path: '',
    redirectTo: 'enterNamePage',
    pathMatch: 'full'
  },
  { path: 'welcomePage' , component: WelcomeComponent },
  { path: '**', component: Page404Component }
];

@NgModule({
  declarations: [
    AppComponent,
    ListBookComponent,
    ListAuthorComponent,
    Page404Component,
    WelcomeComponent,
    NameComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    FormsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
