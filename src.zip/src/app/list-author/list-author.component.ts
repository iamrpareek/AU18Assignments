import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-author',
  templateUrl: './list-author.component.html',
  styleUrls: ['./list-author.component.css']
})
export class ListAuthorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
