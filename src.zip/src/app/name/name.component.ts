import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-name',
  templateUrl: './name.component.html',
  styleUrls: ['./name.component.css']
})
export class NameComponent implements OnInit {

  userLogin = null;

  constructor(private router: Router,private http:HttpClient) { }

  ngOnInit() {
    localStorage.setItem('name', 'Stranger');
  }

  onSubmit() {
    if(this.userLogin != null)
      localStorage.setItem('name', this.userLogin);
    this.router.navigate(['/welcomePage']);
   }

}
